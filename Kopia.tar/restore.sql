--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.zadania DROP CONSTRAINT fk_firma;
ALTER TABLE ONLY public.permutacja_operacje DROP CONSTRAINT "FK_permutacje_operacje_operacja";
ALTER TABLE ONLY public.maszyny_operacje DROP CONSTRAINT "FK_maszyny_zdania_maszyny";
ALTER TABLE ONLY public.maszyny_operacje DROP CONSTRAINT "FK_maszyny_zadania_zadania";
ALTER TABLE ONLY public.operacje DROP CONSTRAINT "FK_id_proces";
ALTER TABLE ONLY public.zadania DROP CONSTRAINT pk_id;
ALTER TABLE ONLY public.dane_firmy DROP CONSTRAINT klucz_glowny;
ALTER TABLE ONLY public.maszyny_operacje DROP CONSTRAINT "UNIQUE_maszyny_zadania_id";
ALTER TABLE ONLY public.permutacja_operacje DROP CONSTRAINT "PK_permutacja_id";
ALTER TABLE ONLY public.maszyny_operacje DROP CONSTRAINT "PK_maszyny_zadania";
ALTER TABLE ONLY public.operacje DROP CONSTRAINT "PK_id";
ALTER TABLE ONLY public.maszyny DROP CONSTRAINT "PK_Maszyny_id";
DROP TABLE public.zadania;
DROP SEQUENCE public.zadania_seq;
DROP TABLE public.permutacja_operacje;
DROP SEQUENCE public.permutacja_operacje_seq;
DROP TABLE public.operacje;
DROP SEQUENCE public.operacje_seq;
DROP TABLE public.maszyny_operacje;
DROP SEQUENCE public.maszyny_operacje_seq;
DROP TABLE public.maszyny;
DROP SEQUENCE public.maszyny_seq;
DROP TABLE public.dane_firmy;
DROP SEQUENCE public.dane_firmy_seq;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: dane_firmy_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE dane_firmy_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dane_firmy_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dane_firmy; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE dane_firmy (
    id integer DEFAULT nextval('dane_firmy_seq'::regclass) NOT NULL,
    nazwa text,
    adres text
);


ALTER TABLE public.dane_firmy OWNER TO postgres;

--
-- Name: maszyny_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE maszyny_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maszyny_seq OWNER TO postgres;

--
-- Name: maszyny; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE maszyny (
    id integer DEFAULT nextval('maszyny_seq'::regclass) NOT NULL,
    opis text
);


ALTER TABLE public.maszyny OWNER TO postgres;

--
-- Name: maszyny_operacje_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE maszyny_operacje_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maszyny_operacje_seq OWNER TO postgres;

--
-- Name: maszyny_operacje; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE maszyny_operacje (
    id integer DEFAULT nextval('maszyny_operacje_seq'::regclass) NOT NULL,
    id_operacje integer,
    id_maszyna integer
);


ALTER TABLE public.maszyny_operacje OWNER TO postgres;

--
-- Name: operacje_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE operacje_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.operacje_seq OWNER TO postgres;

--
-- Name: operacje; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE operacje (
    id integer DEFAULT nextval('operacje_seq'::regclass) NOT NULL,
    koszt integer,
    id_zadania integer
);


ALTER TABLE public.operacje OWNER TO postgres;

--
-- Name: permutacja_operacje_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE permutacja_operacje_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permutacja_operacje_seq OWNER TO postgres;

--
-- Name: permutacja_operacje; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE permutacja_operacje (
    id integer DEFAULT nextval('permutacja_operacje_seq'::regclass) NOT NULL,
    id_operacja integer,
    kolejnosc integer
);


ALTER TABLE public.permutacja_operacje OWNER TO postgres;

--
-- Name: COLUMN permutacja_operacje.id_operacja; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN permutacja_operacje.id_operacja IS '
';


--
-- Name: zadania_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE zadania_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.zadania_seq OWNER TO postgres;

--
-- Name: zadania; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE zadania (
    id integer DEFAULT nextval('zadania_seq'::regclass) NOT NULL,
    data_przyjecia date,
    id_firmy integer NOT NULL,
    data_obliczenia date
);


ALTER TABLE public.zadania OWNER TO postgres;

--
-- Data for Name: dane_firmy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dane_firmy (id, nazwa, adres) FROM stdin;
\.
COPY dane_firmy (id, nazwa, adres) FROM '$$PATH$$/2026.dat';

--
-- Name: dane_firmy_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('dane_firmy_seq', 19, true);


--
-- Data for Name: maszyny; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY maszyny (id, opis) FROM stdin;
\.
COPY maszyny (id, opis) FROM '$$PATH$$/2028.dat';

--
-- Data for Name: maszyny_operacje; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY maszyny_operacje (id, id_operacje, id_maszyna) FROM stdin;
\.
COPY maszyny_operacje (id, id_operacje, id_maszyna) FROM '$$PATH$$/2030.dat';

--
-- Name: maszyny_operacje_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('maszyny_operacje_seq', 6, true);


--
-- Name: maszyny_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('maszyny_seq', 14, true);


--
-- Data for Name: operacje; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY operacje (id, koszt, id_zadania) FROM stdin;
\.
COPY operacje (id, koszt, id_zadania) FROM '$$PATH$$/2032.dat';

--
-- Name: operacje_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('operacje_seq', 11, true);


--
-- Data for Name: permutacja_operacje; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY permutacja_operacje (id, id_operacja, kolejnosc) FROM stdin;
\.
COPY permutacja_operacje (id, id_operacja, kolejnosc) FROM '$$PATH$$/2034.dat';

--
-- Name: permutacja_operacje_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('permutacja_operacje_seq', 2, true);


--
-- Data for Name: zadania; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY zadania (id, data_przyjecia, id_firmy, data_obliczenia) FROM stdin;
\.
COPY zadania (id, data_przyjecia, id_firmy, data_obliczenia) FROM '$$PATH$$/2036.dat';

--
-- Name: zadania_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('zadania_seq', 19, true);


--
-- Name: PK_Maszyny_id; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY maszyny
    ADD CONSTRAINT "PK_Maszyny_id" PRIMARY KEY (id);


--
-- Name: PK_id; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY operacje
    ADD CONSTRAINT "PK_id" PRIMARY KEY (id);


--
-- Name: PK_maszyny_zadania; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY maszyny_operacje
    ADD CONSTRAINT "PK_maszyny_zadania" PRIMARY KEY (id);


--
-- Name: PK_permutacja_id; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY permutacja_operacje
    ADD CONSTRAINT "PK_permutacja_id" PRIMARY KEY (id);


--
-- Name: UNIQUE_maszyny_zadania_id; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY maszyny_operacje
    ADD CONSTRAINT "UNIQUE_maszyny_zadania_id" UNIQUE (id);


--
-- Name: klucz_glowny; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY dane_firmy
    ADD CONSTRAINT klucz_glowny PRIMARY KEY (id);


--
-- Name: pk_id; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY zadania
    ADD CONSTRAINT pk_id PRIMARY KEY (id);


--
-- Name: FK_id_proces; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY operacje
    ADD CONSTRAINT "FK_id_proces" FOREIGN KEY (id_zadania) REFERENCES zadania(id);


--
-- Name: FK_maszyny_zadania_zadania; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY maszyny_operacje
    ADD CONSTRAINT "FK_maszyny_zadania_zadania" FOREIGN KEY (id_operacje) REFERENCES operacje(id);


--
-- Name: FK_maszyny_zdania_maszyny; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY maszyny_operacje
    ADD CONSTRAINT "FK_maszyny_zdania_maszyny" FOREIGN KEY (id_maszyna) REFERENCES maszyny(id);


--
-- Name: FK_permutacje_operacje_operacja; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY permutacja_operacje
    ADD CONSTRAINT "FK_permutacje_operacje_operacja" FOREIGN KEY (id_operacja) REFERENCES operacje(id);


--
-- Name: fk_firma; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY zadania
    ADD CONSTRAINT fk_firma FOREIGN KEY (id_firmy) REFERENCES dane_firmy(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

